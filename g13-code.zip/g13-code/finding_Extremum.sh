python3 -W ignore  ./Finding_Extremum/finding_Extremum.py
